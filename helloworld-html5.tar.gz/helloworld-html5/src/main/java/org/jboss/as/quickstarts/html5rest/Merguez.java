package org.jboss.as.quickstarts.html5rest;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Merguez implements Serializable {

    Long id;

    String texte;

    Long id_user;

    public Merguez () {
        // TODO Auto-generated constructor stub
    }

    public Merguez(Long id_user, String text) {
        // TODO Auto-generated constructor stub
        this.id_user = id_user;
        this.texte = text;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIdentifiant() {
        return texte;
    }

    public void setIdentifiant(String merguez) {
        this.texte = merguez;
    }
}
