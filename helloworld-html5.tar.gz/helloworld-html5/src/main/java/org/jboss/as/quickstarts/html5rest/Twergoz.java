package org.jboss.as.quickstarts.html5rest;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Twergoz implements Serializable {

    private static final long serialVersionUID = 1L;

        Long id;

        String username;

        String password;

        String confirm_password;

        String email;

    public Twergoz() {
                // TODO Auto-generated constructor stub
    }

    public Twergoz(String pseudo, String mdp) {
                // TODO Auto-generated constructor stub
    }

    public Twergoz(String pseudo, String mdp, String mail) {
                // TODO Auto-generated constructor stub
         this.username = pseudo;
         this.password = mdp;
         this.email = mail;
    }

        public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public String getPasswd() {
        return password;
    }

    public void setPasswd(String password) {
        this.password = password;
    }

    public String getPasswdc() {
        return password;
    }

    public void setPasswdc(String passwordc) {
        this.confirm_password = passwordc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
