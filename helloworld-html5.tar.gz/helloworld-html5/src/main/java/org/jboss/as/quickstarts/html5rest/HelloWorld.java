/*
 * JBoss, Home of Professional Open Source
 * Copyright 2015, Red Hat, Inc. and/or its affiliates, and individual
 * contributors by the @authors tag. See the copyright.txt in the
 * distribution for a full listing of individual contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jboss.as.quickstarts.html5rest;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;

/**
 * A simple REST service which is able to say hello to someone using HelloService Please take a look at the web.xml where JAX-RS
 * is enabled And notice the @PathParam which expects the URL to contain /json/David or /xml/Mary
 *
 * @author bsutter@redhat.com
 */

@Path("/")
public class HelloWorld {
    @Inject
    HelloService helloService;

    @GET
    @Path("/json/connexion/{pseudo}/{mdp}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces("application/json")
    public Response getConnexion(@PathParam("pseudo") String pseudo,@PathParam("mdp") String mdp/*Twergoz twergoz*/) {
        //System.out.println("name: " + pseudo);
        //return "{\"result\":\"" + helloService.createHelloMessage(pseudo) + "\"}";
        /*String pseudo = twergoz.getusername();
        String mdp = twergoz.getPasswd();*/
        //return Response.status(200).entity("OK").build();
        if(pseudo.length()<=1) {
            return Response.status(403).entity("Format Username Incorrect").build();
        }
        if(pseudo.length()>=20) {
            return Response.status(403).entity("Format Username Incorrect").build();
        }
        if(mdp.length()<=5) {
            return Response.status(403).entity("Format Password Incorrect").build();
        }
        if(mdp.length()>=20) {
            return Response.status(403).entity("Format Password Incorrect").build();
        }
        int value=requeteHttp.connexion(pseudo,mdp);
        if(value<=0) {
            return Response.status(401).entity("Username or Password Incorrect").build();
        }
        else {
            return Response.status(200).entity("OK - Connexion OK").build();
        }
    }

    @POST
    @Path("/json/inscription/{pseudo}/{mdp}/{mdp1}/{mail}")
    @Produces("application/json")
    public Response setInscription(@PathParam("pseudo") String pseudo,@PathParam("mdp") String mdp,@PathParam("mdp1") String mdp1,@PathParam("mail") String mail) {
        //System.out.println("name : "+ name);
        if(pseudo.length()<=1) {
            return Response.status(403).entity("Format Username Incorrect").build();
        }
        if(pseudo.length()>=20) {
            return Response.status(403).entity("Format Username Incorrect").build();
        }
        if(mdp.length()<=5) {
            return Response.status(403).entity("Format Password Incorrect").build();
        }
        if(mdp.length()>=20) {
            return Response.status(403).entity("Format Password Incorrect").build();
        }
        if(!mdp.equals(mdp1)) {
            return Response.status(403).entity("Password Different").build();
        }
        if(mail.length()<=10) {
            return Response.status(403).entity("Format Email Incorrect").build();
        }
        if(mail.length()>=50) {
            return Response.status(403).entity("Format Email Incorrect").build();
        }
        if(!mail.contains("@")) {
            return Response.status(403).entity("Format Email Incorrect").build();
        }
        int value=requeteHttp.inscription(pseudo,mdp,mail);
        if(value==0) {
            return Response.status(401).entity("Inscription Failed").build();
        }
        else {
            return Response.status(200).entity("OK - Inscription OK").build();
        }
    }

    @GET
    @Path("/json/merguez/{id}")
    @Produces("application/json")
    public Response getMerguezJSON(@PathParam("id") int id_user) {
        //System.out.println("name : "+ name);
        /*String val=requeteHttp.verifieId(id_user);
        if(val.equals("NOK"))
            return Response.status(401).entity("Identification Incorrect").build();*/
        String value=requeteHttp.getTweet(id_user);
        if(value.equals("NOK")) {
            return Response.status(401).entity("Recuperation Tweet Failed").build();
        }
        else {
            return Response.status(200).entity(value).build();
        }
    }

    @POST
    @Path("/json/merguez/{id}/{merguez}")
    @Produces("application/json")
    public Response setMerguezJSON(@PathParam("id") int id_user,@PathParam("merguez") String text) {
        //System.out.println("name : "+ name);
        /*String val=requeteHttp.verifieId(id_user);
        if(val.equals(""))
            return Response.status(401).entity("Identification Incorrect").build();*/
        if(text.length()<=10) {
            return Response.status(403).entity("Format Merguez Incorrect").build();
        }
        if(text.length()>=120) {
            return Response.status(403).entity("Format Merguez Incorrect").build();
        }
        int value=requeteHttp.setTweet(id_user,text);
        if(value==0) {
            return Response.status(401).entity("Add Merguez Failed").build();
        }
        else {
            return Response.status(200).entity("OK - Add Merguez OK").build();
        }
    }

    @GET
    @Path("/json/home")
    @Produces("application/json")
    public Response getHomeJSON()  {
        //System.out.println("name : "+ name);
        String value=requeteHttp.getTweet();
        if(value.equals("NOK")) {
            return Response.status(401).entity("Recuperation Tweet Failed").build();
        }
        else {
            return Response.status(200).entity(value).build();
        }
    }

    @GET
    @Path("/home/{id_user}")
    @Produces("application/json")
    public String getHomeJSON(@PathParam("id_user") int id_user,@PathParam("email") String email)  {
        //System.out.println("name : "+ name);
        return "{\"result\":\"" + "Salut" + "\"}";
    }

    @PUT
    @Path("/changePseudo/{id_user}/{pseudo}")
    @Produces("application/json")
    public String updatePseudo(@PathParam("id_user") int id_user,@PathParam("pseudo") String pseudo)  {
        //System.out.println("name : "+ name);
        return "{\"result\":\"" + "Salut" + "\"}";
    }

    @PUT
    @Path("/changeMdp/{id_user}/{mdp}")
    @Produces("application/json")
    public String updateMdp(@PathParam("id_user") int id_user,@PathParam("mdp") String mdp)  {
        //System.out.println("name : "+ name);
        return "{\"result\":\"" + "Salut" + "\"}";
    }

    @PUT
    @Path("/changeEmail/{id_user}/{email}")
    @Produces("application/json")
    public String updateEmail(@PathParam("id_user") int id_user,@PathParam("email") String email)  {
        //System.out.println("name : "+ name);
        return "{\"result\":\"" + "Salut" + "\"}";
    }

    @POST
    @Path("/like/{id_merguez}/{id_user}")
    @Produces("application/json")
    public Response setLike(@PathParam("id_merguez") int id_merguez,@PathParam("id_user") int id_user)  {
        //System.out.println("name : "+ name);
        String val=requeteHttp.verifieId(id_user);
        if(val.equals(null))
            return Response.status(401).entity("Identification Incorrect").build();
        int value=requeteHttp.setLike(id_merguez,id_user);
        if(value==0) {
            return Response.status(401).entity("Add Like Failed").build();
        }
        else {
            return Response.status(200).entity("OK").build();
        }
    }

    @GET
    @Path("/like/{id_merguez}")
    @Produces("application/json")
    public Response getLike(@PathParam("id_merguez") int id_user)  {
        //System.out.println("name : "+ name);
        int value=requeteHttp.getLike(id_user);
        if(value==-1) {
            return Response.status(401).entity("Add Like Failed").build();
        }
        else {
            return Response.status(200).entity(String.valueOf(value)).build();
        }
    }

    @POST
    @Path("/comment/{id_merguez}/{id_user}/{text}")
    @Produces("application/json")
    public Response setComment(@PathParam("id_merguez") int id_merguez,@PathParam("id_user") int id_user,@PathParam("text") String text)  {
        //System.out.println("name : "+ name);
        /*String val=requeteHttp.verifieId(id_user);
        if(val.equals("NOK"))
            return Response.status(401).entity("Identification Incorrect").build();*/
        if(text.length()<=10) {
            return Response.status(403).entity("Format Merguez Incorrect").build();
        }
        if(text.length()>=120) {
            return Response.status(403).entity("Format Merguez Incorrect").build();
        }
        int value=requeteHttp.setComment(id_merguez,id_user,text);
        if(value==-1) {
            return Response.status(401).entity("Add Like Failed").build();
        }
        else {
            return Response.status(200).entity(String.valueOf(value)).build();
        }
    }

    @GET
    @Path("/comment/{id_merguez}")
    @Produces("application/json")
    public Response getComment(@PathParam("id_merguez") int id_merguez)  {
        //System.out.println("name : "+ name);
        String value=requeteHttp.getComment(id_merguez);
        if(value.equals(null)) {
            return Response.status(401).entity("Recuperation Tweet Failed").build();
        }
        else {
            return Response.status(200).entity(value).build();
        }
    }

    @POST
    @Path("/follow/{id_user}/{id_user_follow}")
    @Produces("application/json")
    public Response setFollow(@PathParam("id_user") int id_user,@PathParam("id_user_follow") int id_user_follow)  {
        //System.out.println("name : "+ name);
        String val=requeteHttp.verifieId(id_user);
        if(val.equals(null))
            return Response.status(401).entity("Identification Incorrect").build();
        int value=requeteHttp.setFollow(id_user,id_user_follow);
        if(value==0) {
            return Response.status(401).entity("Add Follow Failed").build();
        }
        else {
            return Response.status(200).entity("OK").build();
        }
    }

    @GET
    @Path("/follow/{id_user}")
    @Produces("application/json")
    public Response getFollow(@PathParam("id_user") int id_user)  {
        //System.out.println("name : "+ name);        String val=requeteHttp.verifieId(id_user);
        /*if(val.equals(null))
            return Response.status(401).entity("Identification Incorrect").build();*/
        String value=requeteHttp.getFollow(id_user);
        if(value.equals(null)) {
            return Response.status(401).entity("Recuperation Follow Failed").build();
        }
        else {
            return Response.status(200).entity(value).build();
        }
    }
}
