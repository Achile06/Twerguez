package org.jboss.as.quickstarts.html5rest;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;

public class requeteHttp    {

    public requeteHttp() {
        // TODO Auto-generated constructor stub
    }

    public static int inscription(String pseudo,String mdp,String email) {
        try{
            InputStream flux=new FileInputStream("twergoz.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            int cpt=1;
            String ligne;
            while ((ligne=buff.readLine())!=null){
                cpt++;
            }
            buff.close();
            FileWriter fichier = new FileWriter("twergoz.txt",true);
            fichier.write(cpt+";"+pseudo+";"+mdp+";"+email+"\n");
            fichier.close();
            return 1;
            } catch (Exception e){
                e.printStackTrace();
                return 0;
            }
    }

    public static int connexion(String pseudo,String mdp) {
        try{
            InputStream flux=new FileInputStream("twergoz.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            int cpt=0;
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
                if(list[1].equals(pseudo))
                    if(list[2].equals(mdp))
                    {
                        return cpt++;
                    }
                cpt++;
            }
            return -1;
            } catch (Exception e){
                return 0;
            }
    }

    public static String verifieId(int id) {
        try{
            InputStream flux=new FileInputStream("twergoz.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
/*                if(Integer.parseInt(list[0])=id)
                        return list[1] + "OK\n";*/
            }
            return "NOK";
            } catch (Exception e){
                return "NOK";
            }
    }

    public static int setTweet(int id_user, String text) {
        try{
            InputStream flux=new FileInputStream("tweet.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            int cpt=1;
            String ligne;
            while ((ligne=buff.readLine())!=null){
                cpt++;
            }
            buff.close();
            FileWriter fichier = new FileWriter("/home/isen/tweet.txt",true);
            fichier.write(cpt+";"+id_user+";"+text+"\n");
            fichier.close();
            return 1;
            } catch (Exception e){
                return 0;
            }
    }

    public static String getTweet(int id_user) {
        try{
            InputStream flux=new FileInputStream("/home/isen/tweet.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            String result="";
            int cpt=0;
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
                if(list[1].equals(String.valueOf(id_user)))
                {
                    result =result + list[2]+"\n";
                    cpt++;
                }
            }
            buff.close();
            return result+"OK \n";
            } catch (Exception e){
                return "NOK";
            }
    }

    public static String getTweet() {
        try{
            InputStream flux=new FileInputStream("/home/isen/tweet.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            int cpt=0;
            String list_tweet ="";
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
                list_tweet =list_tweet+ list[2]+"\n";
                cpt++;
                }
            buff.close();
            return list_tweet+"OK \n";
            } catch (Exception e){
                return "NOK";
            }
    }

    public static int setLike(int id_comment, int id_user) {
        try{
            InputStream flux=new FileInputStream("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/like.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            int cpt=1;
            String ligne;
            while ((ligne=buff.readLine())!=null){
                cpt++;
            }
            buff.close();
            FileWriter fichier = new FileWriter("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/like.txt",true);
            fichier.write(cpt+";"+id_comment+";"+id_user+"\n");
            fichier.close();
            return 1;
            } catch (Exception e){
                return 0;
            }
    }

    public static int getLike(int id_comment) {
        try{
            InputStream flux=new FileInputStream("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/like.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            int cpt=0;
            String[] list_tweet = new String[100];
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
                if(list[1].equals(String.valueOf(id_comment)))
                {
                    cpt++;
                }
            }
            buff.close();
            return cpt;
            } catch (Exception e){
                return -1;
            }
    }

    public static int setComment(int id_comment, int id_user,String text) {
        try{
            InputStream flux=new FileInputStream("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/comment.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            int cpt=1;
            String ligne;
            while ((ligne=buff.readLine())!=null){
                cpt++;
            }
            buff.close();
            FileWriter fichier = new FileWriter("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/comment.txt",true);
            fichier.write(cpt+";"+id_comment+";"+id_user+";"+text+"\n");
            fichier.close();
            return 1;
            } catch (Exception e){
                return 0;
            }
    }

    public static String getComment(int id_comment) {
        try{
            InputStream flux=new FileInputStream("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/comment.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            int cpt=0;
            String list_tweet ="";
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
                if(list[1].equals(String.valueOf(id_comment)))
                {
                    list_tweet =list_tweet + list[3]+"\n";
                    cpt++;
                }
            }
            buff.close();
            return list_tweet;
            } catch (Exception e){
                return null;
            }
    }

    public static int setFollow(int id_user, int id_user_follow) {
        try{
            InputStream flux=new FileInputStream("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/follow.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            int cpt=1;
            String ligne;
            while ((ligne=buff.readLine())!=null){
                cpt++;
            }
            buff.close();
            FileWriter fichier = new FileWriter("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/follow.txt",true);
            fichier.write(cpt+";"+id_user+";"+id_user_follow+"\n");
            fichier.close();
            return 1;
            } catch (Exception e){
                return 0;
            }
    }

    public static String getFollow(int id_user) {
        try{
            InputStream flux=new FileInputStream("/home/isen/Téléchargements/quickstart-master/helloworld-html5/src/main/java/org/jboss/as/quickstarts/html5rest/follow.txt");
            InputStreamReader lecture=new InputStreamReader(flux);
            BufferedReader buff=new BufferedReader(lecture);
            String ligne;
            int cpt=0;
            String list_tweet = "";
            while ((ligne=buff.readLine())!=null){
                String[] list = ligne.split(";");
                if(list[1].equals(String.valueOf(id_user)))
                {
                    list_tweet =list_tweet + list[2] +"\n";
                    cpt++;
                }
            }
            buff.close();
            return list_tweet;
            } catch (Exception e){
                return null;
            }
    }
}
